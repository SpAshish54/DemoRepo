import { Component, OnInit } from '@angular/core';
import { ParameterService } from '../parameter.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-parameter',
  templateUrl: './parameter.component.html',
  styleUrls: ['./parameter.component.css'],
})
export class ParameterComponent implements OnInit {
  parameters: any[] = [];
  newParameter: any = {
    name: '',
    internalName: '',
    details: '',
    type: 'quantity',
    value: '',
  };
  selectedParameter: any = {};
  featureInternalName: string = '';
  isEditing: boolean = false;

  constructor(private parameterService: ParameterService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    // Retrieve featureInternalName from route parameters
    this.route.params.subscribe(params => {
      this.featureInternalName = params['internalName'];
      // Call your function to load parameters based on featureInternalName
      this.loadParameters();
      console.log(this.featureInternalName)
    });
  }
  
  loadParameters(): void {
    // Use this.featureInternalName to load parameters
    this.parameterService.getParametersByFeatureInternalName(this.featureInternalName).subscribe((parameters) => {
      this.parameters = parameters;
    });
  }

  addParameter(parameter: any): void {
    const featureInternalName = this.route.snapshot.paramMap.get('internalName') || '';
    if (this.isValidParameter(parameter)) {
      this.parameterService.addParameterToFeature(featureInternalName, parameter).subscribe(() => {
        this.loadParameters();
        this.resetNewParameter();
      });
    }
  }
  

  updateParameter(parameter: any): void {
    if (this.isValidParameter(parameter)) {
      this.parameterService.updateParameter(parameter).subscribe(() => {
        this.loadParameters();
        this.selectedParameter = {};
      });
    }
  }

  editParameter(parameter: any): void {
    this.isEditing = true;
    this.selectedParameter = { ...parameter };
  }

  deleteParameter(internalName: string): void {
    this.parameterService.deleteParameter(internalName).subscribe(() => {
      this.loadParameters();
    });
  }

  resetNewParameter(): void {
    //this.isEditing = false
    this.newParameter = {
      name: '',
      internalName: '',
      details: '',
      type: 'quantity',
      value: '',
    };
  }

  cancelEdit(): void {
    this.resetNewParameter();
  }

  isValidParameter(parameter: any): boolean {
    if (parameter.type === 'price') {
      return this.isValidFloat(parameter.value);
    } else if (parameter.type === 'quantity') {
      return this.isValidInteger(parameter.value);
    }
    return true;
  }

  isValidFloat(value: string): boolean {
    // Implement logic to check if the value is a valid float/double
    const floatValue = parseFloat(value);
    return !isNaN(floatValue) && isFinite(floatValue);
  }

  isValidInteger(value: string): boolean {
    // Implement logic to check if the value is a valid integer
    const intValue = parseInt(value, 10);
    return !isNaN(intValue) && Number.isInteger(intValue);
  }
}
