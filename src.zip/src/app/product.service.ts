import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  private apiUrl = 'http://localhost:8080/api/products';

  constructor(private http: HttpClient) {}

  getAllProducts(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  getProductByInternalName(internalName: string): Observable<any> {
    const url = `${this.apiUrl}/${internalName}`;
    return this.http.get<any>(url);
  }

  getFeaturesByProductInternalName(productInternalName: string): Observable<any[]> {
    const url = `${this.apiUrl}/${productInternalName}/features`;
    return this.http.get<any[]>(url);
  }

  addProduct(product: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, product);
  }

  updateProduct(productInternalName: string, product: any): Observable<any> {
    const url = `${this.apiUrl}`;
    return this.http.put<any>(url, product);
  }

  deleteProduct(product: any): Observable<any> {
    const url = `${this.apiUrl}?internalName=${product.internalName}`;
    return this.http.delete<any>(url);
  }
}
