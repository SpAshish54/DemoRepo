export interface Product {
    id: number; // Make it optional for new items
    name: string;
    internalName: string;
    details: string;
    maxProductsPerLocation: number;
}

export interface Feature{
    id: number;
    name: string;
    internalName: string;
    details: string;
    productName: string;
    productInternalName: string;
}

export interface Parameter{
    id: number;
    name: string;
    internalName: string;
    parameterType: ParameterType;
    
}
 
export interface ParameterType{
    QUANTITY: number;
    PRICE: number; 
    OTHER: any;
}