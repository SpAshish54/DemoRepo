// feature.component.ts

import { Component, OnInit } from '@angular/core';
import { FeatureService } from '../feature.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Feature } from '../Product';

@Component({
  selector: 'app-feature',
  templateUrl: './feature.component.html',
  styleUrls: ['./feature.component.css']
})

export class FeatureComponent implements OnInit {
  features: any[] = [];
  featureId: number = 0;
  isupdateFeature: boolean = false;
  selectedFeature: Feature = {
    id: 0,
    name: "",
    internalName: "",
    details: "",
    productName: "",
    productInternalName: ""
  };
  isEditing: boolean = false;
  isFeatureSelected: boolean = false;

  constructor(
    private featureService: FeatureService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const productInternalName = params['internalName'];

      if (productInternalName) {
        // Load features based on the productInternalName
        this.loadFeaturesByProductInternalName(productInternalName);
      } else {
        // If productInternalName is not provided, load all features
        this.getAllFeatures();
      }
    });
  }

  loadFeaturesByProductInternalName(productInternalName: string): void {
    this.featureService.getFeaturesByProductInternalName(productInternalName).subscribe(
      (data: any[]) => {
        this.features = data;
      },
      (error) => {
        console.error('Error fetching features:', error);
      }
    );
  }

  getAllFeatures(): void {
    this.featureService.getAllFeatures().subscribe(data => {
      this.features = data;
    });
  }

  getFeatureByInternalName(featureInternalName: string): void {
    this.featureService.getFeatureByInternalName(featureInternalName).subscribe(
      (data: Feature) => {
        this.selectedFeature = data;
        this.isFeatureSelected = true;
        // Fetch parameters based on the selected feature's internalName
        this.loadParametersByFeatureInternalName(this.selectedFeature.internalName);
      },
      (error) => {
        console.error('Error fetching feature:', error);
      }
    );
  }

  addFeatureToProduct(): void {
    const productInternalName = this.route.snapshot.paramMap.get('internalName') || '';
    this.isEditing = true;
    this.featureService.addFeatureToProduct(productInternalName, this.selectedFeature).subscribe(() => {
      this.resetForm();
      this.loadFeaturesByProductInternalName(productInternalName);
    });
  }
  

  updateFeature(): void {
    //console.log(this.selectedFeature);
    this.featureService.updateFeature(this.selectedFeature).subscribe(() => {
      this.resetForm();
      this.loadFeaturesByProductInternalName(this.selectedFeature.productInternalName);
    });
    this.isupdateFeature = true;
    setTimeout(() => {
      this.isupdateFeature = false;
    }, 5000); // Example: Hide the message after 5 seconds

  }

  deleteFeature(): void {
    this.featureService.deleteFeature(this.selectedFeature).subscribe(() => {
      this.resetForm();
      this.loadFeaturesByProductInternalName(this.selectedFeature.productInternalName);
    });
  }

  loadParametersByFeatureInternalName(featureInternalName: string): void {
    this.featureService.getParametersByFeatureInternalName(featureInternalName).subscribe(
      (data: any[]) => {
        this.features = data;
      },
      (error) => {
        console.error('Error fetching parameters:', error);
      }
    );
  }

  cancelEdit(): void {
    this.resetForm();
  }

  
  selectFeature(feature: any): void {
    this.isFeatureSelected = true;
    this.selectedFeature = { ...feature };
    // Set the productInternalName
    this.selectedFeature.productInternalName = feature.productInternalName;
  }
  
  
  resetForm(): void {
    this.isEditing = false;
    this.selectedFeature = {
      id: 0,
      name: "",
      internalName: "",
      details: "",
      productName: "",
      productInternalName: ""
    };
  }
  
  editFeature(): void {
    this.isEditing = true;
  }
  
  viewParameters(featureInternalName: string): void {
    // Implement your logic to view parameters based on the selected feature
    this.loadFeaturesByProductInternalName(featureInternalName)
    this.router.navigate(['/parameters', featureInternalName]);
  }
  
}
