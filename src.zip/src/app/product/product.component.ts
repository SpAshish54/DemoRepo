// product.component.ts

import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../Product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  products: any[] = [];
  productId: number = 0;
  selectedProduct: Product = {
    "id": 0,
    "name": "",
    "internalName": "",
    "details": "",
    "maxProductsPerLocation": 0
  };
  isEditing: boolean = false;
  features: any[] = [];

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const internalName = params['internalName'];
      if (internalName) {
        this.getProductDetails(internalName);
      } else {
        this.getAllProducts();
      }
    });
  }

  getProductDetails(internalName: string): void {
    this.productService.getProductByInternalName(internalName).subscribe(
      (data: any) => {
        this.selectedProduct = data;
        this.getFeaturesByProductInternalName(internalName);
      },
      (error) => {
        console.error('Error fetching product details:', error);
      }
    );
  }

  getAllProducts(): void {
    this.productService.getAllProducts().subscribe(data => {
      this.products = data;
    });
  }

  getFeaturesByProductInternalName(internalName: string): void {
    if (internalName) {
      this.productService.getFeaturesByProductInternalName(internalName).subscribe(
        (data: any[]) => {
          this.features = data;
          console.log('Features data:', this.features);
        },
        (error) => {
          console.error('Error fetching features:', error);
        }
      );
    } else {
      console.error('Internal name is not available for fetching features.');
    }
  }

  selectProduct(product: any): void {
    this.selectedProduct = { ...product };
  }

  addProduct(): void {
    this.productService.addProduct(this.selectedProduct).subscribe(() => {
      this.resetForm();
      this.getAllProducts();
    });
  }

  updateProduct(): void {
    this.productService.updateProduct(this.selectedProduct.internalName, this.selectedProduct).subscribe(() => {
      this.resetForm();
      this.getAllProducts();
    });
  }

  deleteProduct(): void {
    this.productService.deleteProduct(this.selectedProduct).subscribe(() => {
      this.resetForm();
      this.getAllProducts();
    });
  }

  resetForm(): void {
    this.isEditing = false;
    this.productId = 0;
  }

  // ViewFeatures(productInternalName: string): void {
  //   this.getFeaturesByProductInternalName(productInternalName);
  // }


  // product.component.ts

  // navigateToFeatureComponent(feature: any): void {
  //   console.log('Feature object:', feature);

  //   const productInternalName = this.selectedProduct?.internalName;
  //   const featureInternalName = feature?.internalName;

  //   if (productInternalName && featureInternalName) {
  //     this.router.navigate(['/products', productInternalName, 'features', featureInternalName]);
  //   } else {
  //     console.error('Product internalName or feature internalName is undefined.');
  //   }
  // }
  // product.component.ts

  ViewFeatures(productInternalName: string): void {
    // Set the selected product
    this.getProductDetails(productInternalName);

    // Navigate to the FeatureComponent with the product's internalName
    this.router.navigate(['/features', productInternalName]);
    
  }


}
