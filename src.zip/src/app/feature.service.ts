import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FeatureService {
  private baseUrl = 'http://localhost:8080/api/features';

  constructor(private http: HttpClient) { }

  addFeatureToProduct(productInternalName: string, feature: any): Observable<void> {
    const url = `${this.baseUrl}/${productInternalName}`;
    return this.http.post<void>(url, feature);
  }
   
  getParametersByFeatureInternalName(featureInternalName: string): Observable<any[]> {
    const url = `${this.baseUrl}/${featureInternalName}/parameters`;
    return this.http.get<any[]>(url);
  }
  
  getAllFeatures(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  getFeatureByInternalName(featureInternalName: string): Observable<any> {
    const url = `${this.baseUrl}/${featureInternalName}`;
    return this.http.get<any>(url);
  }


  getFeaturesByProductInternalName(productInternalName: string): Observable<any[]> {
    const url = `${this.baseUrl}/product/${productInternalName}`;
    return this.http.get<any[]>(url);
  }

  updateFeature(feature: any): Observable<any> {
    const url = `${this.baseUrl}`;
    return this.http.put<any>(url, feature);
  }

  deleteFeature(feature: any): Observable<void> {
    const url = `${this.baseUrl}?internalName=${feature.internalName}`;
    return this.http.delete<void>(url);
  }
}
