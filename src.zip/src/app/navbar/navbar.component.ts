import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  locations = ['Hyderabad', 'Bangalore', 'Mumbai']; // Add your actual locations
  selectedLocation: string = '';
  isDropdownOpen: boolean = false;

  toggleDropdown(): void {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  changeLocation(location: string): void {
    this.selectedLocation = location;
    this.isDropdownOpen = false; // Close the dropdown after selecting a location
  }
}
